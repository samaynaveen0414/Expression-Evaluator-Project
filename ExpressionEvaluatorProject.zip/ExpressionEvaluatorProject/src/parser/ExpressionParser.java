package parser;

import stacks.UnboundedStack;
import stackExceptionPackage.StackUnderflowException;

import java.util.StringTokenizer;

public class ExpressionParser {
    private UnboundedStack<Double> valueStack;
    private UnboundedStack<Character> operatorStack;
    
    public ExpressionParser() {
        valueStack = new UnboundedStack<>();
        operatorStack = new UnboundedStack<>();
    }
    
    public double evaluate(String expression) throws StackUnderflowException {
        valueStack = new UnboundedStack<>();
        operatorStack = new UnboundedStack<>();
        StringTokenizer tokenizer = new StringTokenizer(expression, " +-*/%()", true);
        boolean expectingOperand = true; 
        while (tokenizer.hasMoreTokens()) {
            String token = tokenizer.nextToken().trim();
            if (token.isEmpty()) continue;

            if (isNumber(token)) {
                valueStack.push(Double.parseDouble(token));
                expectingOperand = false;
            } else if (token.equals("-") && expectingOperand) {
                String nextToken = tokenizer.nextToken().trim();
                if (!isNumber(nextToken)) {
                    throw new IllegalArgumentException("Invalid expression: expected a number after unary minus");
                }
                valueStack.push(-Double.parseDouble(nextToken));
                expectingOperand = false;
            } else if (isOperator(token)) {
                processOperator(token.charAt(0));
                expectingOperand = true;
            } else if (token.equals("(")) {
                operatorStack.push('(');
                expectingOperand = true;
            } else if (token.equals(")")) {
                processRightParenthesis();
                expectingOperand = false;
            } else {
                throw new IllegalArgumentException("Invalid token: " + token);
            }
        }
        while (!operatorStack.isEmpty()) {
            applyOperator(operatorStack.top());
            operatorStack.pop();
        }
        if (valueStack.getCurrentDepth() != 1) {
            throw new IllegalStateException("Invalid expression.");
        }
        return valueStack.top();
    }

    private boolean isNumber(String token) {
        try {
            Double.parseDouble(token);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean isOperator(String token) {
        return "+-*/%".contains(token);
    }

    private void processOperator(char thisOp) throws StackUnderflowException {
        while (!operatorStack.isEmpty() && precedence(operatorStack.top()) >= precedence(thisOp)) {
            applyOperator(operatorStack.top());
            operatorStack.pop();
        }
        operatorStack.push(thisOp);
    }

    private void processRightParenthesis() throws StackUnderflowException {
        while (operatorStack.top() != '(') {
            applyOperator(operatorStack.top());
            operatorStack.pop();
        }
        operatorStack.pop(); 
    }
    
    private void applyOperator(char operator) throws StackUnderflowException {
        if (valueStack.getCurrentDepth() < 2) {
            throw new IllegalStateException("Insufficient operands for the operator.");
        }
        double right = valueStack.top();
        valueStack.pop();
        double left = valueStack.top();
        valueStack.pop();
        switch (operator) {
            case '+': valueStack.push(left + right); break;
            case '-': valueStack.push(left - right); break;
            case '*': valueStack.push(left * right); break;
            case '/': 
                if (right == 0) throw new ArithmeticException("Division by zero");
                valueStack.push(left / right); break;
            case '%': 
                if (right == 0) throw new ArithmeticException("Modulus by zero");
                valueStack.push(left % right); break;
            default: throw new IllegalArgumentException("Invalid operator: " + operator);
        }
    }
    private int precedence(char op) {
        if (op == '+' || op == '-') return 1;
        if (op == '*' || op == '/' || op == '%') return 2;
        return -1;
    }
    
    public int getMaxOperandStackDepth() {
        return valueStack.getMaxDepth();
    }
    
    public int getMaxOperatorStackDepth() {
        return operatorStack.getMaxDepth();
    }
}
