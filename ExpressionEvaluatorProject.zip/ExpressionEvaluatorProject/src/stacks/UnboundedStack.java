package stacks;


import stackExceptionPackage.StackUnderflowException;
import java.util.ArrayList;

public class UnboundedStack<T> implements StackInterface<T> {
    private ArrayList<T> stack;
    private int maxDepth;

    public UnboundedStack() {
        stack = new ArrayList<>();
        maxDepth = 0;
    }

    public void push(T element) {
        stack.add(element);
        if (stack.size() > maxDepth) {
            maxDepth = stack.size();
        }
    }

    public void pop() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException();
        }
        stack.remove(stack.size() - 1);
    }

    public T top() throws StackUnderflowException {
        if (isEmpty()) {
            throw new StackUnderflowException();
        }
        return stack.get(stack.size() - 1);
    }

    public boolean isEmpty() {
        return stack.isEmpty();
    }

    public boolean isFull() {
        return false;
    }

    public int getMaxDepth() {
        return maxDepth;
    }

    public int getCurrentDepth() {
        return stack.size();
    }
}
